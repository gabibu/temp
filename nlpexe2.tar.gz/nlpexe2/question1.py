
import sys
#
#
def wordsStat(lines):
    numOfUnigram = 0
    uniqueWords = set()

    for line in lines:
        numOfUnigram += len(line)
        uniqueWords = uniqueWords.union(line)

    return numOfUnigram,  len(uniqueWords)
#
def tagsStat(tags):
    numOfTags = 0
    uniqueTags = set()
    for lineTags in tags:
        numOfTags += len(lineTags)
        uniqueTags = uniqueTags.union(lineTags)

    return numOfTags, len(uniqueTags)


def avgWordTags(lines, tags):
    wordToUniqueTags = {}
    for lineIndex, lineWords in enumerate(lines):
        lineTags = tags[lineIndex]


        for wordIndex, word in enumerate(lineWords):
            wordTag = lineTags[wordIndex]

            if word not in wordToUniqueTags:
                wordToUniqueTags[word] = set()

            wordToUniqueTags[word].add(wordTag)


    sumOfUniqueTags = 0.0

    for wordTags in  wordToUniqueTags.values():
        sumOfUniqueTags += len(wordTags)

    avg = sumOfUniqueTags / float(len(wordToUniqueTags))

    return avg

def readTaggedFile(filePath):
    currentLine = []
    currentTags = []

    with open(filePath, "r") as ins:

        lines = []
        tags = []

        for line in ins:
            stripped = line.rstrip()
            if stripped == '':
                if len(currentLine) > 0:
                    lines.append(currentLine)
                    tags.append(currentTags)
                    currentTags = []
                    currentLine = []
                    continue

            segment, tag = stripped.split('\t')
            currentLine.append(segment)
            currentTags.append(tag)

    if len(currentLine) > 0:
        lines.append(currentLine)
        tags.append(currentTags)

    return lines, tags




if __name__ == '__main__':
    file = sys.argv[1]

    lines, tags = readTaggedFile(file)

    #1.1             1.2
    numOfUnigram, numOfUniqueWords  = wordsStat(lines)

    #1.3         1.4
    numOfTags, uniqueTagsLength = tagsStat(tags)

    #1.5
    avg = avgWordTags(lines, tags)


    print(avg)






