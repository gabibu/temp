
from utils.Constants import SENTENSE_START
import utils.Constants
from entities.Ngrams import Ngram
from entities.BP import  BPIndex
from math import log
from utils.filereader import reafEmissionsProbabilitiesParamaters,reafLexicalProbabilitiesParamaters,readSentenses


def calcV(index, word, tag, tagsOptions, wordToTagToLogProg, gramsToLogProb, sentense, bpIndexTable):

    if index == 0:
        return 1
    else:
        maxV = None
        maxPrevTag = None
        prevIndex = index - 1

        if prevIndex > 0:
            prevTagsToUse = tagsOptions
        else:
            prevTagsToUse =[SENTENSE_START]

        maxPrevTag = None

        for prevTag in prevTagsToUse:

            prevVres =calcV(prevIndex,sentense[index-1], prevTag, tagsOptions, wordToTagToLogProg, gramsToLogProb,
                            sentense, bpIndexTable)

            key = Ngram(prevTag, tag)


            if key in gramsToLogProb:
                transitionLogProg =gramsToLogProb[key]
            else:
                transitionLogProg = log(0.00000000000001)

            emissionLogProb = None
            if word in wordToTagToLogProg:
                if tag in wordToTagToLogProg[word]:
                    emissionLogProb =  wordToTagToLogProg[word][tag]

            if emissionLogProb is None:
                emissionLogProb = log(0.00000000000001)

            currentV = prevVres + emissionLogProb + transitionLogProg

            if maxV is None or maxV < currentV:
                maxV = currentV
                maxPrevTag = prevTag

        indexKey = BPIndex(index, tag)
        bpIndexTable[indexKey] = [maxV, maxPrevTag]
        return maxV


def tagSentense(sentense, wordToTagToLogProg, gramsToLogProb, tags):
    v = {}

    v[BPIndex(0, SENTENSE_START)] = 1
    bpIndexTable = {}
    for enIndex, word in enumerate(sentense):
        maxV = None
        bpTag = None
        wordIndex  = enIndex+ 1
        for currentTag in tags:
            curV = calcV(wordIndex,  word, currentTag,
                  tags, wordToTagToLogProg, gramsToLogProb, sentense, bpIndexTable)

            if maxV is None or curV > maxV:
                maxV = curV
                bpTag = currentTag



def tag(emissionParamasFile, lexicalParamasFile, fileToTag, resFile):
    wordToTagToLogProg, tags = reafEmissionsProbabilitiesParamaters(emissionParamasFile)
    gramsToLogProb = reafLexicalProbabilitiesParamaters(lexicalParamasFile)
    sentenses = readSentenses(fileToTag)

    for sentense in sentenses:
        tagSentense(sentense, wordToTagToLogProg, gramsToLogProb, tags)

    print('done')
