

class BPIndex:

    def __init__(self, index, back):
        self.index = index
        self.back = back
