

from utils import filereader

def tag(paramatersFile, fileToTag, resFile):

    sentenses = filereader.readSentenses(fileToTag)
    wordToTag = filereader.readBasicParamaters(paramatersFile)

    sentensesTags = []
    for sentene in sentenses:
        sentenseWordTags = []
        for word in sentene:
            tag = 'NNP'
            if word in wordToTag:
                tag = wordToTag[word]

            sentenseWordTags.append([word, tag])

        sentensesTags.append(sentenseWordTags)


    with open(resFile, 'w') as file:
        for sentenseTags in sentensesTags:

            for word,tag in sentenseTags:

                file.write('{0}\t{1}\n'.format(word, tag))

            file.write('\n')

    print(sentensesTags)


