
import sys
from utils.filereader import readFiles, read, readSegmentMostFrequestTag




if __name__ == '__main__':
    filesCsv = sys.argv[1]

    files = filesCsv.split(',')

    segmentToMostFreTag = readSegmentMostFrequestTag(files[0])

    with open('q1p.txt', 'w') as file:

        for word, tag in segmentToMostFreTag.items():
            file.write('{0} {1}\n'.format(word, tag))




    print('completed')