

import sys
from evaluation.Evaluator import evaluate

if __name__ == '__main__':

    taggedFile = sys.argv[1]
    goldFile = sys.argv[2]
    resFile = sys.argv[3]

    evaluate(taggedFile, goldFile, resFile, "basic", "y")

