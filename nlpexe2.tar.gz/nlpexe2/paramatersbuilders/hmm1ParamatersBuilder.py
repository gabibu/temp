

from math import  log
from utils.Constants import SENTENSE_START,SENTENSE_END
from utils.filereader import readLinesAndTags
from entities import Ngrams

def buidParamaters(inputFile, emissionProbFile, tagProbFile):

    linesWordsAndTags = readLinesAndTags(inputFile)

    twoGram = {}
    tagToWordCount = {}
    oneGram = {}

    startOneGram = Ngrams.Ngram(SENTENSE_START)
    oneGram[startOneGram] = 0

    numberOfOneGrams = 0
    for line in linesWordsAndTags:

        prevTag = SENTENSE_START
        oneGram[startOneGram] = oneGram[startOneGram] + 1
        numberOfOneGrams  = numberOfOneGrams +1
        for word, tag in line:

            numberOfOneGrams = numberOfOneGrams + 1
            oneGramKey = Ngrams.Ngram(tag)

            if oneGramKey not  in oneGram:
                oneGram[oneGramKey] = 0

            oneGram[oneGramKey] = oneGram[oneGramKey] + 1

            twoGramKey = Ngrams.Ngram(prevTag, tag)
            if twoGramKey not in twoGram:
                twoGram[twoGramKey] = 0

            twoGram[twoGramKey] = twoGram[twoGramKey] + 1

            if tag not in tagToWordCount:
                tagToWordCount[tag] = {}

            if word not in tagToWordCount[tag]:
                tagToWordCount[tag][word] = 0

            tagToWordCount[tag][word] = tagToWordCount[tag][word] + 1

            prevTag = tag

            twoGramKey = Ngrams.Ngram(prevTag, SENTENSE_END)
            if twoGramKey not in twoGram:
                twoGram[twoGramKey] = 0

            twoGram[twoGramKey] = twoGram[twoGramKey] + 1


    for twoGramKey, twoGounterCounter in twoGram.items():
        key1 = twoGramKey.key1
        oneGramKey = Ngrams.Ngram(key1)
        singleCounter = oneGram[oneGramKey]

        prob = twoGounterCounter / float(singleCounter)

        logProb = log(prob)

        print(logProb)


    wordToGivenTagLogPro = {}
    for tag, wourdToCounter in tagToWordCount.items():
        oneGramKey = Ngrams.Ngram(tag)
        singleCounter = oneGram[oneGramKey]

        tagsSum = 0
        for word, wordCounter in wourdToCounter.items():
            prob = float(wordCounter) /singleCounter

            logProb = log(prob)
            tagsSum = tagsSum+ wordCounter
            print(prob)

            if word not in wordToGivenTagLogPro:
                wordToGivenTagLogPro[word] = []

            wordToGivenTagLogPro[word].append([tag, logProb])

        if tagsSum != singleCounter:
            print('error!!!')

    with open(emissionProbFile, 'w') as file:

        for word, tagsLogProg in wordToGivenTagLogPro.items():

            file.write('{0}\t'.format(word))
            for tag, logProb in tagsLogProg:
                file.write('{0}\t{1}\t'.format(tag, logProb))
            file.write('\n')



    with open(tagProbFile, 'w') as file:

        file.write('\\data\\\n')
        file.write('ngram 1 = {0}\n'.format(len(oneGram)))
        file.write('ngram 2 = {0}\n'.format(len(twoGram)))

        file.write('\n')
        file.write('\\1-grams\\\n')

        for key, counter in oneGram.items():
            tag = key.key1
            prob = counter / numberOfOneGrams
            logProb = log(prob)

            file.write('{0}\t{1}\t\n'.format(logProb, tag))

        file.write('\n')

        file.write('\\2-grams\\\n')

        for key, counter in twoGram.items():
            given = key.key1
            actual = key.key2

            oneGramKey = Ngrams.Ngram(given)

            oneCounter = oneGram[oneGramKey]
            prob = float(counter) / oneCounter

            logProb = log(prob)

            file.write('{0}\t{1}\t{2}\n'.format(logProb, given, actual))






