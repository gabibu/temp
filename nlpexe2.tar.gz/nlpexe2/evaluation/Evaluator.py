
from utils.filereader import readLinesAndTags


def evaluate(taggedFile, goldFile, resFile, model, isSmoothing):

    goldFileLines, goldFileTaggs = readLinesAndTags(goldFile)
    taggedFileLines, taggedFileTaggs = readLinesAndTags(taggedFile)


    lineLengthAndCorrectCounter = []

    for lineIndex, lineTaggs in  enumerate(taggedFileTaggs):
        goldTaggs = goldFileTaggs[lineIndex]

        correctCounter = 0
        for tagIndex, tag in enumerate(lineTaggs):
            goldTag = goldTaggs[tagIndex]

            if goldTag == tag:
                correctCounter += 1

        lineLengthAndCorrectCounter.append([len(lineTaggs), correctCounter])

    totalNunOfWords = 0
    totalNunOfCorrectTaggedWords = 0
    correctSentenses = 0

    lineIndex =  1
    with open(resFile, 'w') as file:

        file.write("#————————————————————————\n")
        file.write("# Part-of-Speech Tagging Evaluation\n")
        file.write("#————————————————————————\n")
        file.write("#\n")
        file.write("# Model: {0}\n".format(model))
        file.write("# Smoothing: {0}\n".format(isSmoothing))
        file.write("# Test File: {0}\n".format(taggedFile))
        file.write("# Gold File: : {0}\n".format(goldFile))
        file.write("#\n")
        file.write("#————————————————————————\n")
        file.write("# sent-num word-accuracy sent-accuracy\n")
        file.write("#————————————————————————\n")




        for lineLength, correctCounter in lineLengthAndCorrectCounter:

            wordAccurcy = float(correctCounter) / lineLength

            totalNunOfWords += lineLength
            totalNunOfCorrectTaggedWords += correctCounter

            if correctCounter == lineLength:
                lineAccuracy =  1
                correctSentenses += 1
            else:
                lineAccuracy = 0

            file.write('{0}\t{1}\t{2}\n'.format(lineIndex, wordAccurcy, lineAccuracy))

            lineIndex += 1

        file.write("#————————————————————————\n")

        corpusWordAccuracy = float(totalNunOfCorrectTaggedWords) / totalNunOfWords
        corpusSentensesAccuracy = float(correctSentenses) / len(lineLengthAndCorrectCounter)


        file.write('macro-avg {0}\t{1}\n'.format(corpusWordAccuracy, corpusSentensesAccuracy))












