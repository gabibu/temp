

class Ngram:

    def __init__(self, key1, key2 =None, key3=None, key4=None):
        self.key1 = key1
        self.key2 = key2
        self.key3 = key3
        self.key4 = key4

    def __eq__(self, other):
        return self.key1 == other.key1 and self.key2 == other.key2 \
               and self.key3 == other.key3 and self.key4 == other.key4


    def __hash__(self) -> int:
        return 31 * hash(self.key1) * hash(self.key2)\
        * hash(self.key3) * hash(self.key4)
