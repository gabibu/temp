

from utils.Constants import SENTENSE_START
from utils.Constants import SENTENSE_END
from utils.filereader import  readSentenses
from math import log
def readGramLine(line):
    values = line.split('\t')

    tags = []
    for index, tag in enumerate(values):
        if index == 0:
            logProb = values[0]
        else:
            tags.append(tag)

    return tuple(tags), logProb

def reafLexicalProbabilitiesParamaters(filePath):
    with open(filePath, "r") as f:
        lines = f.readlines()

        gramIndex = 1
        gramToRows = {}
        lineIndex = 1
        while True:
            line = lines[lineIndex].rstrip()
            lineIndex = lineIndex + 1
            if line == '':
                break

            count = line.split('=')[1].rstrip()
            gramToRows[1] = int(count)
            gramIndex = gramIndex + 1

        # skip line
        lineIndex = lineIndex + 1

        gramsToProb = {}
        gram = 1
        while lineIndex < len(lines):
            line = lines[lineIndex].rstrip()

            if line == '':
                gram = gram + 1
                print('gram - > {0}'.format(gram))
                lineIndex = lineIndex + 2
                continue

            ngram, logProb = readGramLine(line)
            gramsToProb[ngram] = float(logProb)

            lineIndex = lineIndex + 1

        return gramsToProb

def reafEmissionsProbabilitiesParamaters(filePath):
    wordTagLogProb = {}
    tags = set()
    words = set()
    with open(filePath, "r") as ins:

        for line in ins:
            if line != '':
                segmentTagsProbs = line.rstrip()

                values = segmentTagsProbs.split('\t')

                word = values[0]
                index = 1

                words.add(word)
                while index < len(values):
                    tag = values[index]
                    logProb = values[index + 1]
                    tags.add(tag)

                    wordTagLogProb[(word, tag)] = float(logProb)

                    index  = index + 2

    return wordTagLogProb, tags, words

class HMMViterbuTagger:

    def __init__(self, hmmK, eFile = None, qFile=None, trainFile = None,
                 testFile = None, taggedFile = None):

        self.hmmK = hmmK
        self.trainFile = trainFile
        self.eFile = eFile
        self.qFile = qFile
        self.testFile = testFile
        self.taggedFile = taggedFile
        self.tagWordCounter = {}
        self.nGramsToApperanceCounter = {}
        self.ngramTypeTotal = {}

        if trainFile is not None:
            self.nGramsToApperanceCounter[0] = {}

            for index in range(0, hmmK + 2):
                self.nGramsToApperanceCounter[index] = {}
                self.ngramTypeTotal[index] = 0

            self.nGramsToApperanceCounter[0][tuple([])] = 0
        else:
            self.wordTagLogProb, self.tags, self.words = reafEmissionsProbabilitiesParamaters(eFile)
            self.gramsToLogProb = reafLexicalProbabilitiesParamaters(qFile)


    def getE(self, word, tag):

        wordTagKey = tuple([word, tag])
        if wordTagKey in self.wordTagLogProb:
            return self.wordTagLogProb[wordTagKey]

        else:
            return float('inf')

    def getQ(self, gram):
        mechane = tuple(gram[0: len(gram) -1])
        mone = tuple(gram)

        if mone in self.gramsToLogProb:
            return self.gramsToLogProb[mone] / mechane
        else:
            return float('inf')


    def transitionProb(self, given, target):
        ngram = given[:]
        ngram.append(target)

        key = tuple(ngram)

        if key in self.gramsToLogProb:
            logProb = self.gramsToLogProb[tuple(ngram)]
            return logProb

        return -float('inf')

    def emissionProb(self, word, tag):

        key = (word, tag)
        if key in self.wordTagLogProb:
            return self.wordTagLogProb[key]

        if word not in self.words:
            if tag == 'NNP':
                return log(1)

        return -float('inf')



    def viterbi(self, sentense):
        bpV = {}
        index = []
        index.append(0)

        for x in  range(0, self.hmmK):
            index.append(SENTENSE_START)


        bpV[tuple(index)] = log(1)
        bpt = {}

        for k in range(1, len(sentense) + 1):
            wordIndex = k - 1
            word = self.wordFromSntense(sentense, wordIndex)

            indexPossiblesTags = self.indexPossibleTags(wordIndex, len(sentense))
            prevIndexesTags = self.indexesPrevTags(wordIndex, len(sentense))

            for currentTag in indexPossiblesTags:
                for prevTags in prevIndexesTags:

                    transitionLogProb = self.transitionProb(prevTags, currentTag)
                    emissionLogProb = self.emissionProb(word, currentTag)
                    prevTagsVIndex = prevTags[:]
                    prevTagsVIndex.insert(0, k-1)

                    prevMaxV = bpV[tuple(prevTagsVIndex)]

                    val = prevMaxV + transitionLogProb+ emissionLogProb

                    currentVindexList = []
                    currentVindexList.append(k)
                    currentVindexList.extend(prevTags[1:])

                    currentVindexList.append(currentTag)

                    currentIndexKey = tuple(currentVindexList)

                    if currentIndexKey not in bpV or bpV[currentIndexKey] < val:
                        bpV[currentIndexKey] = val
                        bpt[currentIndexKey] = prevTags[-1]


        matchedTags = []
        lastMax = None
        bestLastTags = None
        indexPossiblesTags = self.indexPossibleTags(len(sentense), len(sentense))
        prevIndexesTags = self.indexesPrevTags(len(sentense), len(sentense))

        for currentTag in indexPossiblesTags:
            for prevTags in prevIndexesTags:
                transitionLogProb = self.transitionProb(prevTags, currentTag)
                prevTagsVIndex = prevTags[:]
                prevTagsVIndex.insert(0, len(sentense))

                prevMaxV = bpV[tuple(prevTagsVIndex)]
                val = prevMaxV + transitionLogProb

                if lastMax is None or lastMax < val:
                    lastMax = val
                    bestLastTags = prevTags


        wordIndex = len(sentense) -1


        matchedTags.append([sentense[wordIndex], bestLastTags[-1]])
        wordIndex -= 1
        bastNext = bestLastTags
        for k in range(len(sentense)  - self.hmmK, 0, -1):
            currentVindexList = []
            currentVindexList.append(k + 1)
            currentVindexList.extend(bastNext)
            prevBestMatch = bpt[tuple(currentVindexList)]

            word = sentense[wordIndex]

            matchedTags.insert(0, [word, prevBestMatch])
            edited = bastNext[0: len(bastNext)-1]
            edited.insert(0, prevBestMatch)
            bastNext = edited
            wordIndex -= 1

        return matchedTags















    def calcV(self, v, vIndex, bpV):
        if vIndex < 0:
            return 1

        prevIndex = vIndex - 1
        prevTags = self.indexTags(prevIndex)

        maxFoundPrevTag = None
        maxPrevV = - float('inf')

        prevTags = self.indexesTags(vIndex)


    def indexesPrevTags(self, currentIndex, sentenseLength):

        indexesTags = []
        for index in range(currentIndex - self.hmmK, currentIndex):
            indexTags = self.indexPossibleTags(index, sentenseLength)
            indexesTags.append(indexTags)

        arrays = []

        for arrayIndex in range(0, len(indexesTags)):
            copyArrays = []
            for prevIndexTag in indexesTags[arrayIndex]:
                if len(arrays) == 0:
                    copyArrays.append([prevIndexTag])

                else:
                    for arr in arrays:
                        currentCopy = arr[:]
                        currentCopy.append(prevIndexTag)
                        copyArrays.append(currentCopy)

            arrays = copyArrays

        return copyArrays


    def indexPossibleTags(self, index, sentenseLength):
        if index < 0:
            startTags = []
            startTags.append(SENTENSE_START)
            return startTags

        if index > sentenseLength -1:
            endTags = []
            endTags.append(SENTENSE_END)
            return endTags

        return self.tags


    def wordFromSntense(self, sentense, index):
        if index < 0:
            return SENTENSE_START

        return sentense[index]

    def addSentsensePro(self, sentense):

        sentenseTags = []
        sentenseTags.append(SENTENSE_START)
        for tagSegment in  sentense:
            sentenseTags.append(tagSegment[0])
            if tagSegment not in  self.tagWordCounter:
                self.tagWordCounter[tagSegment] = 0

            self.tagWordCounter[tagSegment] += 1

        sentenseTags.append(SENTENSE_END)

        self.nGramsToApperanceCounter[0][tuple([])] += len(sentenseTags)

        for tagIndex, tag in enumerate(sentenseTags):

            backIndex = tagIndex
            while backIndex >= 0:

                ngramKey = tuple(sentenseTags[backIndex: tagIndex +1])

                if len(ngramKey) in self.nGramsToApperanceCounter:

                    if ngramKey not in self.nGramsToApperanceCounter[len(ngramKey)]:
                        self.nGramsToApperanceCounter[len(ngramKey)][ngramKey] = 0

                    self.nGramsToApperanceCounter[len(ngramKey)][ngramKey] += 1

                    self.ngramTypeTotal[len(ngramKey)] += 1
                    backIndex -= 1
                else:
                    break

    def train(self):
        currentSentense = []
        for line in open(self.trainFile, 'r'):
            line = line.strip()

            if line:
                segment, tag = line.split('\t')
                currentSentense.append((tag, segment))
            else:
                if len(currentSentense) > 0:
                    self.addSentsensePro(currentSentense)

                currentSentense = []

        wordToTagAndProb =self.produceEmissionProb()
        self.writeEmissionProbabilities(wordToTagAndProb)
        self.writeLexicalParamaters()

    def decode(self):
        sentenses = readSentenses(self.testFile)

        sentensesTags = []
        for sentense in sentenses:
            sentenseTagged = self.viterbi(sentense)
            sentensesTags.append(sentenseTagged)

        with open(self.taggedFile, 'w') as file:
            for sentenseTags in sentensesTags:

                for word, tag in sentenseTags:
                    file.write('{0}\t{1}\n'.format(word, tag))

                file.write('\n')




    def writeLexicalParamaters(self):
        with open(self.qFile, 'w') as file:
            file.write('\\data\\\n')
            for index in range(1, self.hmmK + 2):
                file.write('ngram {0} = {1}\n'.format(index, self.ngramTypeTotal[index]))

            file.write('\n')

            for index in range(1, self.hmmK + 2):
                file.write('\\{0}-gram\\\n'.format(index))

                for keys, counter in  self.nGramsToApperanceCounter[index].items():
                    keysList = list(keys)
                    keysStr = ''
                    prevKeys = []
                    for keyIndex, key in  enumerate(keysList):
                        keysStr += key
                        keysStr += '\t'

                        if keyIndex < len(keysList) -1:
                            prevKeys.append(key)

                    indexKey = tuple(prevKeys)

                    prevCounter = self.nGramsToApperanceCounter[index-1][indexKey]


                    prob = float(counter) / prevCounter

                    logProb = log(prob)

                    file.write ('{0}\t{1}\n'.format(logProb, keysStr))

                file.write('\n')

    def writeEmissionProbabilities(self, wordToTagAndProb):
        with open(self.eFile, 'w') as file:
            for word, tagsLogProg in wordToTagAndProb.items():

                file.write('{0}\t'.format(word))
                for tag, logProb in tagsLogProg:
                    file.write('{0}\t{1}\t'.format(tag, logProb))

                file.write('\n')

    def produceEmissionProb(self):

        wordToTagsProb = {}
        for tagWord, counter in self.tagWordCounter.items():
            tag, word = tagWord
            tafCounter = self.nGramsToApperanceCounter[1][tuple([tag])]

            prob = float(counter) / tafCounter
            logPorv = log(prob)

            if word not in wordToTagsProb:
                wordToTagsProb[word] = []

            wordToTagsProb[word].append([tag, logPorv])

        return wordToTagsProb

    def increaseCounters(self, tagsSequnce):

        self.nGramsToApperanceCounter[0][tuple([])] += 1

        for i in range(0, self.hmmK +1):
            k = i + 1

            currentNGram = self.nGramsToApperanceCounter[k]

            kTags = tuple(tagsSequnce[len(tagsSequnce) - k:]) #tuple(tagsSequnce[:k])
            if kTags not in currentNGram:
                currentNGram[kTags] = 0

            currentNGram[kTags] += 1

if __name__ == '__main__':

    eFile = '/home/gabib3b/mycode/git/pyspark/nlpexe2/res/hmm1/e1.txt'
    qFile = '/home/gabib3b/mycode/git/pyspark/nlpexe2/res/hmm1/11.txt'
    trainFile = '/home/gabib3b/mycode/git/pyspark/nlpexe2/testfiles/heb-pos.train'
    tagResFile = '/home/gabib3b/mycode/git/pyspark/nlpexe2/res/hmm1/res1.txt'

    # Train
    hmm1 = HMMViterbuTagger(1, eFile, qFile,  trainFile)
    #hmm1.train()

    testFile = '/home/gabib3b/mycode/git/pyspark/nlpexe2/testfiles/heb-pos.test'

    hmm1 = HMMViterbuTagger(1, eFile, qFile, None, testFile, tagResFile)
    hmm1.decode()


    #tag


    goldFile ='/home/gabib3b/mycode/git/pyspark/nlpexe2/testfiles/heb-pos.gold'
    evaluationFile = '/home/gabib3b/mycode/git/pyspark/nlpexe2/res/hmm1/eval.txt'
    from evaluation.Evaluator import evaluate

    evaluate(tagResFile, goldFile, evaluationFile ,
             'basic', False)



