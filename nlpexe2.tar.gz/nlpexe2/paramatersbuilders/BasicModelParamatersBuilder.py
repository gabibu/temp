
from utils.filereader import readSegmentMostFrequestTag

def readSegmentMostFrequestTag(filePath):

    with open(filePath, "r") as ins:

        segmentTagsCounter = {}

        for line in ins:
            stripped = line.rstrip()
            if stripped == '':
                continue

            segment, tag = stripped.split('\t')

            if segment not in  segmentTagsCounter:
                segmentTagsCounter[segment] = {}

            tagToCounter = segmentTagsCounter[segment]


            if tag not in tagToCounter:
                tagToCounter[tag] = 0

            tagToCounter[tag] = tagToCounter[tag] + 1

    segmentToMostFreTag = {}
    for segment, tagsCounter in segmentTagsCounter.items():
        maxCounter = 0
        maxCounterTag = None

        for tag, counter in tagsCounter.items():

            if counter > maxCounter:
                maxCounter = counter
                maxCounterTag = tag

        segmentToMostFreTag[segment] = maxCounterTag


    return segmentToMostFreTag


def buidParamaters(inputFile, outputFile):
    segmentToMostFreTag = readSegmentMostFrequestTag(inputFile)

    with open(outputFile, 'w') as file:

        for word, tag in segmentToMostFreTag.items():
            file.write('{0}\t{1}\n'.format(word, tag))


