

from copyHMM import HMM

train = '/home/gabib3b/mycode/git/pyspark/nlpexe2/testfiles/heb-pos.train'
test = '/home/gabib3b/mycode/git/pyspark/nlpexe2/testfiles/heb-pos.test'
res = '/home/gabib3b/mycode/git/pyspark/nlpexe2/testfiles/rescopy.test'

model = HMM(train, test)

model.tagger(res)