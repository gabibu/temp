

import sys
import filesreader

if __name__ == '__main__':

    paramatersFile = sys.argv[1]
    taggerFile = sys.argv[2]

    sentenses = filesreader.readSentenses(taggerFile)
    wordToTag = filesreader.readBasicParamaters(paramatersFile)

    sentensesTags = []
    for sentene in sentenses:
        sentenseWordTags = []
        for word in sentene:
            tag = 'NNP'
            if word in wordToTag:
                tag = wordToTag[word]

            sentenseWordTags.append([word, tag])

        sentensesTags.append(sentenseWordTags)


    with open('q2ptaggs.txt', 'w') as file:
        for sentenseTags in sentensesTags:

            for word,tag in sentenseTags:

                file.write('{0} {1}\n'.format(word, tag))

            file.write('\n')

    print(sentensesTags)


