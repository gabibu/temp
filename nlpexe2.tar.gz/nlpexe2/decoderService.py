import sys
from decoders.BasicDecoder import tag
from decoders import hmm1Decoder

if __name__ == '__main__':
    paramatersFile = sys.argv[1]
    lexicalFile = sys.argv[2]
    testFile = sys.argv[3]
    #tag(paramatersFile, fileToTag, resFile)

    hmm1Decoder.tag(paramatersFile, lexicalFile, testFile, None)