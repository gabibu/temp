import sys
from decoders.BasicDecoder import tag
from decoders import hmm1Decoder

from decoders.HMMViterbi import HMMViterbuTagger

if __name__ == '__main__':
    emission = sys.argv[1]
    transition = sys.argv[2]
    testFile = sys.argv[3]
    #tag(paramatersFile, fileToTag, resFile)

    #hmm1Decoder.tag(paramatersFile, lexicalFile, testFile, None)



    tagger = HMMViterbuTagger(1, emission, transition, None, testFile)
    tagger.decode()