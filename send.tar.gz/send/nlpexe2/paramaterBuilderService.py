

import sys
from paramatersbuilders.BasicModelParamatersBuilder import buidParamaters
from paramatersbuilders import hmm1ParamatersBuilder
from decoders.HMMViterbi import HMMViterbuTagger

if __name__ == '__main__':

    inputFile = sys.argv[1]
    emission = sys.argv[2]
    tag = sys.argv[3]

    tagger = HMMViterbuTagger(1, emission, tag, inputFile)
    tagger.train()


    #buidParamaters(inputFile, resFile)

    #hmm1ParamatersBuilder.buidParamaters(inputFile, emission, tag)
    #with open(tag, 'w') as file:
    #    file.write('\\tgabu\\t')
