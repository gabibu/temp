
import sys
from filesreader import read, readFiles


def wordsStat(lines):
    numOfUnigram = 0
    uniqueWords = set()

    for line in lines:
        numOfUnigram += len(line)
        uniqueWords = uniqueWords.union(line)

    return numOfUnigram,  len(uniqueWords)

def tagsStat(tags):
    numOfTags = 0
    uniqueTags = set()
    for lineTags in tags:
        numOfTags += len(lineTags)
        uniqueTags = uniqueTags.union(lineTags)

    return numOfTags, len(uniqueTags)


def avgWordTags(lines, tags):
    wordToUniqueTags = {}
    for lineIndex, lineWords in enumerate(lines):
        lineTags = tags[lineIndex]


        for wordIndex, word in enumerate(lineWords):
            wordTag = lineTags[wordIndex]

            if word not in wordToUniqueTags:
                wordToUniqueTags[word] = set()

            wordToUniqueTags[word].add(wordTag)


    sumOfUniqueTags = 0.0

    for wordTags in  wordToUniqueTags.values():
        sumOfUniqueTags += len(wordTags)

    avg = sumOfUniqueTags / float(len(wordToUniqueTags))

    return avg

if __name__ == '__main__':
    filesCsv = sys.argv[1]
    files = filesCsv.split(',')

    lines, tags = readFiles(files)

    numOfUnigram, numOfUniqueWords  = wordsStat(lines)

    numOfTags, uniqueTagsLength = tagsStat(tags)

    avg = avgWordTags(lines, tags)


    print(avg)






