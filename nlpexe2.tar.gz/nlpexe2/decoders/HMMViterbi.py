
#from utils.filereader import reafLexicalProbabilitiesParamaters,readSentenses

from utils.Constants import SENTENSE_START
from utils.Constants import SENTENSE_END


def readGramLine(line):
    values = line.split('\t')

    tags = []
    for index, tag in enumerate(values):
        if index == 0:
            logProb = values[0]
        else:
            tags.append(tag)

    return tuple(tags), logProb

def reafLexicalProbabilitiesParamaters(filePath):
    with open(filePath, "r") as f:
        lines = f.readlines()

        gramIndex = 1
        gramToRows = {}
        lineIndex = 1
        while True:
            line = lines[lineIndex].rstrip()
            lineIndex = lineIndex + 1
            if line == '':
                break

            count = line.split('=')[1].rstrip()
            gramToRows[1] = int(count)
            gramIndex = gramIndex + 1

        # skip line
        lineIndex = lineIndex + 1

        gramsToProb = {}
        gram = 1
        while lineIndex < len(lines):
            line = lines[lineIndex].rstrip()

            if line == '':
                gram = gram + 1
                print('gram - > {0}'.format(gram))
                lineIndex = lineIndex + 2
                continue

            ngram, logProb = readGramLine(line)
            gramsToProb[ngram] = float(logProb)

            lineIndex = lineIndex + 1

        return gramsToProb

def reafEmissionsProbabilitiesParamaters(filePath):
    wordTagLogProb = {}
    tags = set()
    words = set()
    with open(filePath, "r") as ins:

        for line in ins:
            if line != '':
                segmentTagsProbs = line.rstrip()

                values = segmentTagsProbs.split('\t')

                word = values[0]
                index = 1

                words.add(word)
                while index < len(values):
                    tag = values[index]
                    logProb = values[index + 1]
                    tags.add(tag)

                    wordTagLogProb[tuple(word, tag)] = float(logProb)

                    index  = index + 2

    return wordTagLogProb, tags, word

class HMMViterbuTagger:

    def __init__(self, hmmK, eFile = None, qFile=None, trainFile = None):

        self.hmmK = hmmK
        self.trainFile = trainFile
        self.eFile = eFile
        self.qFile = qFile
        self.tagWordCounter = {}
        self.nGramsToApperanceCounter = {}
        self.ngramTypeTotal = {}


        if trainFile is not None:
            self.nGramsToApperanceCounter[0] = {}

            for index in range(0, hmmK + 2):
                self.nGramsToApperanceCounter[index] = {}
                self.ngramTypeTotal[index] = 0

            self.nGramsToApperanceCounter[0][tuple([])] = 0
        else:
            self.wordTagLogProb, self.tags, self.words = reafEmissionsProbabilitiesParamaters(eFile)
            self.gramsToLogProb = reafLexicalProbabilitiesParamaters(qFile)


    def getE(self, word, tag):

        wordTagKey = tuple([word, tag])
        if wordTagKey in self.wordTagLogProb:
            return self.wordTagLogProb[wordTagKey]

        else:
            return float('inf')

    def getQ(self, gram):
        mechane = tuple(gram[0: len(gram) -1])
        mone = tuple(gram)

        if mone in self.gramsToLogProb:
            return self.gramsToLogProb[mone] / mechane
        else:
            return float('inf')


    def viterbi(self, sentense):
        bpV = {}
        index = []
        index.append(0)

        for x in  range(0, self.hmmK):
            index.append(SENTENSE_START)


        bpV[tuple(index)] = 1

        for k in range(1, len(sentense) + 1):
            wordIndex = k - 1
            word = self.wordFromSntense(sentense, wordIndex)

            if word not in self.words:
                print('handle!!!!!')

            indexPossiblesTags = self.indexTags(wordIndex)

            for v in indexPossiblesTags:
                pass


    def calcV(self, v, vIndex, bpV):
        if vIndex < 0:
            return 1

        prevIndex = vIndex - 1
        prevTags = self.indexTags(prevIndex)

        maxFoundPrevTag = None
        maxPrevV = - float('inf')

        prevTags = self.indexesTags(vIndex)





    def indexesTags(self, currentIndex):

        indexesTags = []
        for index in range(currentIndex - self.hmmK, currentIndex):
            indexTags = self.indexTags(index)
            indexesTags.append(indexTags)

        arrays = []

        for arrayIndex in range(0, len(indexTags)):
            copyArrays = []
            for val in indexTags[arrayIndex]:
                if len(arrays) == 0:
                    copyArrays.append([val])

                else:
                    for arr in arrays:
                        currentCopy = arr[:]
                        currentCopy.append(val)
                        copyArrays.append(currentCopy)

            arrays = copyArrays

        return copyArrays








        return indexesTags

    def indexTags(self, index):
        if index < 0:
            return [SENTENSE_START]

         return self.tags






    def wordFromSntense(self, sentense, index):
        if index < 0:
            return SENTENSE_START

        return sentense[index]



    def addSentsensePro(self, sentense):

        sentenseTags = []
        sentenseTags.append(SENTENSE_START)
        for tagSegment in  sentense:
            sentenseTags.append(tagSegment[0])
            if tagSegment not in  self.tagWordCounter:
                self.tagWordCounter[tagSegment] = 0

            self.tagWordCounter[tagSegment] += 1

        sentenseTags.append(SENTENSE_END)

        self.nGramsToApperanceCounter[0][tuple([])] += len(sentenseTags)

        for tagIndex, tag in enumerate(sentenseTags):

            backIndex = tagIndex
            while backIndex >= 0:

                ngramKey = tuple(sentenseTags[backIndex: tagIndex +1])

                if len(ngramKey) in self.nGramsToApperanceCounter:

                    if ngramKey not in self.nGramsToApperanceCounter[len(ngramKey)]:
                        self.nGramsToApperanceCounter[len(ngramKey)][ngramKey] = 0

                    self.nGramsToApperanceCounter[len(ngramKey)][ngramKey] += 1

                    self.ngramTypeTotal[len(ngramKey)] += 1
                    backIndex -= 1
                else:
                    break

    def train(self):
        currentSentense = []
        for line in open(self.trainFile, 'r'):
            line = line.strip()

            if line:
                segment, tag = line.split('\t')
                currentSentense.append((tag, segment))
            else:
                if len(currentSentense) > 0:
                    self.addSentsensePro(currentSentense)

                currentSentense = []

        wordToTagAndProb =self.produceEmissionProb()
        self.writeEmissionProbabilities(wordToTagAndProb)
        self.writeLexicalParamaters()

    def decode(self):
        pass

    def writeLexicalParamaters(self):
        with open(self.qFile, 'w') as file:
            file.write('\\data\\\n')
            for index in range(1, self.hmmK + 2):
                file.write('ngram {0} = {1}\n'.format(index, self.ngramTypeTotal[index]))

            for index in range(1, self.hmmK + 2):
                file.write('\\{0}-gram\\\n'.format(index))

                for keys, counter in  self.nGramsToApperanceCounter[index].items():
                    keysList = list(keys)
                    keysStr = ''
                    prevKeys = []
                    for keyIndex, key in  enumerate(keysList):
                        keysStr += key
                        keysStr += '\t'

                        if keyIndex < len(keysList) -1:
                            prevKeys.append(key)

                    indexKey = tuple(prevKeys)

                    prevCounter = self.nGramsToApperanceCounter[index-1][indexKey]

                    #todo: log prob
                    prob = float(counter) / prevCounter
                    # todo: log prob

                    file.write ('{0}\t{1}\n'.format(prob, keysStr))

                file.write('\n')

    def writeEmissionProbabilities(self, wordToTagAndProb):
        with open(self.eFile, 'w') as file:
            for word, tagsLogProg in wordToTagAndProb.items():

                file.write('{0}\t'.format(word))
                for tag, logProb in tagsLogProg:
                    file.write('{0}\t{1}\t'.format(tag, logProb))

                file.write('\n')

    def produceEmissionProb(self):

        wordToTagsProb = {}
        for tagWord, counter in self.tagWordCounter.items():
            tag, word = tagWord
            tafCounter = self.nGramsToApperanceCounter[1][tuple([tag])]
            # todo: log prob!!!
            prob = float(counter) / tafCounter
            #todo: log prob!!!
            if word not in wordToTagsProb:
                wordToTagsProb[word] = []

            wordToTagsProb[word].append([tag, prob])

        return wordToTagsProb

    def increaseCounters(self, tagsSequnce):

        self.nGramsToApperanceCounter[0][tuple([])] += 1

        for i in range(0, self.hmmK +1):
            k = i + 1

            currentNGram = self.nGramsToApperanceCounter[k]

            kTags = tuple(tagsSequnce[len(tagsSequnce) - k:]) #tuple(tagsSequnce[:k])
            if kTags not in currentNGram:
                currentNGram[kTags] = 0

            currentNGram[kTags] += 1


    # def pushTag(self, prevTags, tag):
    #     del prevTags[0]
    #     prevTags.insert(len(prevTags), tag)
    #     return prevTags




